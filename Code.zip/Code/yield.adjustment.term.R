yield.adjustment.term<-function(sigma11=0.005,sigma12=0,sigma13=0,sigma21=-0.001,sigma22=0.003,sigma23=0,sigma31=-0.1,sigma32=0.001,sigma33=0.007,lambda=0.6,time=1)
{
  Atilde<-sigma11^2+sigma12^2+sigma13^2
  
  Btilde<-sigma21^2+sigma22^2+sigma23^2
  
  Ctilde<-sigma31^2+sigma32^2+sigma33^2
  
  Dtilde<-sigma11*sigma21+sigma12*sigma22+sigma13*sigma23
  
  Etilde<-sigma11*sigma31+sigma12*sigma32+sigma13*sigma33
  
  Ftilde<-sigma21*sigma31+sigma22*sigma32+sigma23*sigma33
  
  res1<--Atilde*time^2/6
  
  res2<--Btilde*(1/(2*lambda^2)-(1-exp(-lambda*time))/(lambda^3*time)+(1-exp(-2*lambda*time))/(4*lambda^3*time))
  
  res3<--Ctilde*(1/(2*lambda^2)+exp(-lambda*time)/(lambda^2)-time*exp(-2*lambda*time)/(4*lambda)-3*exp(-2*lambda*time)/(4*lambda^2)-2*(1-exp(-lambda*time))/(lambda^3*time)+5*(1-exp(-2*lambda*time))/(8*lambda^3*time))
  
  res4<--Dtilde*(time/(2*lambda)+exp(-lambda*time)/(lambda^2)-(1-exp(-lambda*time))/(lambda^3*time))
  
  res5<--Etilde*(3*exp(-lambda*time)/(lambda^2)+time/(2*lambda)+time*exp(-lambda*time)/(lambda)-3*(1-exp(-lambda*time))/(lambda^3*time))
  
  res6<--Ftilde*(1/(lambda^2)+exp(-lambda*time)/(lambda^2)-exp(-2*lambda*time)/(2*lambda^2)-3*(1-exp(-lambda*time))/(lambda^3*time)+3*(1-exp(-2*lambda*time))/(4*lambda^3*time))
  
  
  res1+res2+res3+res4+res5+res6
}