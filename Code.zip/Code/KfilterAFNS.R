# Filter
Kfilter<-function(logLik,N,T,Y,B,C,a.t,P.t,H,a.tt,P.tt,v2,v1,Kappa,theta,Q,Phi0,Phi1,prev,Months,Yf,lik){
for (t in 1:T) 
{
  v <- (as.numeric(Y[t, ])) - B %*% a.t[t, ]-as.numeric(C)# prediciton error vector
  F <- B %*% P.t[t, ,] %*% t(B) + H # prediciton error variance matrix
  if(det(F)<=1e-30 || is.na(det(F)) || is.nan(det(F)) || is.infinite(det(F))){
    logLik<- -1000000000000000; break
  }else{
    F.inv  <- solve(F)
    # Log-likelihood
    logLik <- logLik - 0.5 * (log(det(F)) + t(v) %*% F.inv %*% v) # constructed via the prediction error decomposition
    }
    # Updating the state vector and its variance matrix
    a.tt[t, ]   <- a.t[t, ] +  P.t[t, , ] %*% t(B) %*% F.inv %*% v
    P.tt[t, , ] <- P.t[t, , ] - P.t[t, , ] %*% t(B) %*% F.inv %*% B %*% P.t[t, , ]
    v1[t, ]	<- B %*% a.tt[t, ]
    v2[t, ] <- (as.numeric(Y[t, ])) - B %*% a.tt[t, ]-as.numeric(C) # Filtered errors(residuals)
    # Predicting the state vector and its variance matrix
    a.t[t + 1, ]  <- Phi0+Phi1%*%a.tt[t, ]  
    P.t[t + 1, ,] <- Phi1 %*% P.tt[t, ,] %*% t(Phi1) + Q
  }
  # Forecast
  if(prev) 
  {
    if(t > (T - 1))
      for(m in 1:Months)
      {
        Yf[t + m,]<- B %*% a.t[t + m, ] 
        a.tt[t + m, ]<- a.t[t + m, ]
        P.tt[t + m, , ]<- P.t[t + m, , ]
        a.t[t + m + 1, ]  <- Phi1 %*% a.tt[t + m, ] + Phi0  
        P.t[t + m + 1, ,] <- Phi1 %*% P.tt[t + m, ,] %*% t(Phi1) + Q
      }
  }
  if(lik)
  {
    as.numeric(-logLik)
  }else{
    return(list(a.tt=a.tt,a.t=a.t,P.tt=P.tt,P.t=P.t,v2=v2,v1=v1,Yf=Yf)) 
  }
}	
