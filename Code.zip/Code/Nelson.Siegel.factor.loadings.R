'This is the Nelson Sigel factor loadings
In this function, l is the constant decay parameter lambda, m is the maturity.'

Nelson.Siegel.factor.loadings <- function(l,m)
{
  column1 <- rep.int(1,length(m))
  column2 <- (1 - exp(-l * m))/(l * m)
  column3 <- column2 - exp(-l * m)
  
  lambmat <- cbind(column1,column2,column3)
  
  lambmat
}  
