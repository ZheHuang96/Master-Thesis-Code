lyapunov<-function(N,A,Q){
  matrix(solve(diag(N^2) - kronecker(A,A)) %*% matrix(Q,(N^2),1),N,N)
}
