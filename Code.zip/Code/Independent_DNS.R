Sys.setlocale("LC_TIME", "English")
#This is for the independent-factor DNS model
# Data
data<-read.csv("C:/Users/Huang Zhe/Desktop/thesis/code/Final thesis data.csv",header = TRUE, sep = ",")
require(xts)
data<- as.matrix(data[,which(names(data)=="X1M"):which(names(data)=="X120M")])
datas<- seq(as.Date("1996/1/1"), by = "month", length.out = 192)
data<- xts(data, order.by = datas)
#data1<- xts(data, order.by = datas) 


# Initial Parameters (According to Diebold& Rudebusch paper to initial Parameters)  
'Decay Parameter:constant Lambda= 0.0618,
Measurement Equation Error: diag H matrix (7x7) maturity=7,
Measurement Equation corrlated factor AR(1)coeffient matrix:A matrix (3x3), 
VAR(1)mean: mu vector (3x1), 
State Equation Error:Q matrix (3x3). Total: 26 parameters
'
'
para<-c(0.0618,

0.14170940,0.07289485,0.11492339,0.11120008,0.09055795,0.07672075,0.07222108,

0.99010443,0.94256154,0.788078795,


5.0803,-2.0691,-1.7491,  

0.3408764,
0.02661018,1.08802059
 )
'
#parameters after optimization
para<-c(  0.7143682681,
        
          0.0953013017,0.0006567908,0.0675696703,0.1503855008, 0.0646546808,0.0866443216,-0.0156996429,
        
          0.9978968825,0.9777232430,0.9342086095,
        
        
          4.1200461526, -2.5406579868,-1.4222214855,  
        
          0.1987905905,
          0.2920134517,0.5947249283

)

prev<- FALSE # TRUE to Forecast.
#prev<-TRUE
ahead<-3 # X-step ahead forecast:3,6,12
lik <- FALSE # TRUE to return the value of the loglikelihood function. FALSE to return parameters.

# Kalman Filter function,in this function, l is the constant decay parameter lambda, m is the maturity.

kalman <- function(para,Y,lik,prev,ahead) {
l<- para[1]
m<- c(1/12,1/4,1/2,2,5,7,10)
Months<-ahead 
  
# Resize data if Forecast is on.

  if(prev){#*** Forecast
		  T <- nrow(Y)
		  Yf<-Y
		  Yf[(T-Months+1):T,]<-NA
		  Y<-Y[1:(T-Months),]
		  T <- nrow(Y)
  }else{
		  T <- nrow(Y)
		  Yf = 1}#***
#Pars contain all parameters in the estimation  
pars<-list()
W <- ncol(Y)
#Three factors: L,S,C
N <- 3
  
# Create vectors and matrices

pars$mu	<- matrix(NA,N,1) # Mean vector
pars$A<- diag(N) # Vector Autoregressive coeffient matrix VAR(1)	
pars$H	<- diag(ncol(Y)) # Variance matrix of error
pars$Q	<- diag(N) # Transition covariance matrix of error

# Loading matrix

source("C:\\Users\\Huang Zhe\\Desktop\\thesis\\code\\MyCode\\Nelson.Siegel.factor.loadings.R")
pars$B	<- Nelson.Siegel.factor.loadings(l,m) 
  
# Variance matrix of residuals

  for(i in 1:7){
    pars$H[i,i]<-para[1 + i]
  }

H <- pars$H^2
  
# Vector autoregressive coeffient matrix: VAR(1)
pars$A[1,1] <- para[9]
pars$A[2,2] <- para[10]
pars$A[3,3] <- para[11]

  
# Mean vector
pars$mu[1]<-para[12]
pars$mu[2]<-para[13]
pars$mu[3]<-para[14]
  
# Transition covariance matrix of residuals
pars$Q[1,1] <- para[15]
pars$Q[2,2] <- para[16]
pars$Q[3,3] <- para[17]

#Q=qq' 
Q <- pars$Q^2

v1   <- matrix(NA,T,W)			  
v2   <- matrix(NA,T,W) # Filtered errors: are defined as the difference between the observed yield curve and its filtered estimate from KF
  
# Resize data if Forecast is on.
  if(prev){#*** 
	  a.tt <- matrix(NA, (T+Months), N)
	  a.t  <- matrix(NA, (T+Months+1), N) # if prev=TRUE, always will be dim(a.t)[1]=192
	  P.tt <- array(NA, c((T+Months), N, N))
	  P.t  <- array(NA, c((T+Months+1), N, N))
  }else{
	  a.tt <- matrix(NA, T, N)
	  a.t  <- matrix(NA, (T+1), N)
	  P.tt <- array(NA, c(T, N, N))
	  P.t  <- array(NA, c((T+1), N, N))
  }#***
  
# Start state vector and variance matrix
a.t[1, ]  <- pars$mu # Start state vector: pars$at0

# Start variance matrix
lyapunov<-function(N,A,Q){
  matrix(solve(diag(N^2) - kronecker(A,A)) %*% matrix(Q,(N^2),1),N,N)
}
P.t[1, ,] <-lyapunov(N=N,A=pars$A,Q=Q) # Start variance matrix. pars$Pt0
  
# Initial log-likelihood	
logLik <- - 0.5 * T * ncol(Y) * log(2 * pi)

# Kalman Filter and log-likelihood
source("C:\\Users\\Huang Zhe\\Desktop\\thesis\\code\\MyCode\\Kfilter.R")  
Kfilter(logLik=logLik,N=N,T=T,Y=Y,B=pars$B,a.t=a.t,P.t=P.t,H=H,a.tt=a.tt,P.tt=P.tt,v2=v2,v1=v1,A=pars$A,mu=pars$mu,Q=Q,prev=prev,Months=Months,Yf=Yf,lik=lik)
}

results<-kalman(para=para,Y=data,lik=lik,prev=prev,ahead=ahead) #**** 
results

#  -860.0945 full sample loglik

# Numerical Optimization  
otim2<-optim(para,kalman,control = list(maxit=10000),Y=data,lik=lik,prev=prev,ahead=ahead)

# Parameters after optimization
'
para<-c(0.07738452,
0.26726293,0.07443629,0.09040581,0.10480007,0.09931606,0.08645425,0.07852442,0.07207583,0.07269172,0.07909206,0.10295433,0.09261623,0.10050282,0.11161028,0.10670647,0.15070219,0.17327333,

0.99557203,0.02993130,-0.02087407,
-0.02531064,0.93776486,0.03662998,
0.03013432,0.02251098,0.83815771,

8.35291770,-1.44060409,-0.10671270,

0.30815585,
-0.04171767,0.61700758,
0.11418710,0.02219852,0.89692230)
'

lik<-FALSE
prev<-FALSE
results<-kalman(para=para,Y=data,lik=lik,prev=prev,ahead=ahead)
results

#mean
for(i in 1:7)
{
  mean_i<-mean(results$v2[,i])
  print(mean_i)
}
#RMSE
#install.packages("Metrics")
library(Metrics)
for(i in 1:7){
  print(rmse(as.numeric(data[,i]),results$v1[,i]))
}
#forecast rmse
for(i in 1:7){
  print(rmse(as.numeric(data[,i]),results$Yf[,i]))
}
#factors
results$a.tt
Level_indep=ts(results$a.tt[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
