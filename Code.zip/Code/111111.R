m <- c(1/12,1/4,1/2,2,5,7,10)  
l1   <- 1.1913479229
l2   <- 0.39
factor.loadings <- function(l1,l2,m)
{
  column1 <- rep.int(1,length(m))
  column2 <- (1 / (l1 * m)) * exp(-l1 * m) * (exp(l1 * m) - 1)
  column3 <- (1 / (l2 * m)) * exp(-l2 * m) * (exp(l2 * m) - 1)
  column4 <- (1 / (l1 * m)) * exp(-l1 * m) * (-l1 * m + exp(l1 * m) - 1)
  column5 <- (1 / (l2 * m)) * exp(-l2 * m) * (-l2 * m + exp(l2 * m) - 1)
  
  lambmat <- cbind(column1,column2,column3,column4,column5)
  
  lambmat
}  

 factor.loadings(l1=l1, l2=l2,m=m)
 
 
 
 #F
 para<-c(1,19,0.6912,
         0.14170940,0.7289485,0.11492339,0.11120008,0.09055795,0.07672075,0.07222108,
         
         1.001605218,0.927345689,0.788078795,0.13207235,0.6930209375,
         4.4539334622,-2.0504116702,-0.4, -1.0399574245,-0.3,
         
         0.001997376636,0.001747185840,
         0.000724688386,0.00344675961, 0.00425986914)
 Y<-data
 T<-192
 a.tt <- matrix(NA, T, 5)
 a.t  <- matrix(NA, (T+1), 5)
 P.tt <- array(NA, c(T, 5, 5))
 P.t  <- array(NA, c((T+1), 5, 5))
 mu	<- matrix(NA,5,1)
 mu[1]<-para[15]
 mu[2]<-para[16]
 mu[3]<-para[17]
 mu[4]<-para[18]
 mu[5]<-para[19]
 a.t[1, ]  <- mu #pars$at0
 A	<- diag(5)
 H	<- diag(ncol(Y))
 Q	<- diag(5)
 for(i in 1:7){
   H[i,i]<-para[i+2]
 }
 
 H <- H %*% H
 A[1,1] <- para[10]
 A[2,2] <- para[11]
 A[3,3] <- para[12]
 A[4,4] <- para[13]
 A[5,5] <- para[14]
 Q[1,1] <- para[20]
 Q[2,2] <- para[21]
 Q[3,3] <- para[22]
 Q[4,4] <- para[23]
 Q[5,5] <- para[24]
 Q <- Q %*% t(Q) 
 B<-factor.loadings(l1=l1, l2=l2,m=m)
 lyapunov<-function(A,Q){
   matrix(solve(diag(5^2) - kronecker(A,A)) %*% matrix(Q,(5^2),1),5,5)
 }  
 P.t[1, ,] <-lyapunov(A=A,Q=Q) # Start variance matrix. pars$Pt0
 
 for (t in 1:T) 
 {
  
   F <- B %*% P.t[t, ,] %*% t(B) + H # prediciton error variance matrix
   #if(det(F)<=1e-30 || is.na(det(F)) || is.nan(det(F)) || is.infinite(det(F))){
    # break
   #}else{
     F.inv  <- solve(F)
   #}
 }
 '
 otim1
 $par
 [1]  2.142368639  0.590046304  0.047861063  0.038015167 -0.013136321  0.148135235
 [7]  0.044070608  0.087347749  0.003764643  0.954420160  0.701438896  0.988968483
 [13]  0.641262506  0.987302737  4.675120802 -1.468633108 -0.087141349 -1.185883175
 [19] -0.390569507 -0.238156726  0.207993037 -0.297081876  0.426330505  0.549274234
 
$value
 [1] -953.5101
 
 $counts
 function gradient 
 11937       NA 
 
 $convergence
 [1] 0
 
 $message
 NULL
 '
 '> otim1
$par
 [1]  1.431623618  0.053015227  0.061426494  0.027062426  0.032672960  0.154021876
 [7]  0.084835665  0.068776400  0.001670461  0.800344399  0.950563575  0.994038552
[13]  0.943785195  0.987980795  4.620794046 -1.073502237 -0.187954403 -1.420520051
[19] -0.532330296  0.007409997  0.321823577  0.263363450 -0.360849458  0.639470583

$value
[1] -933.938

$counts
function gradient 
    6337       NA 

$convergence
[1] 0

$message
NULL'
 '#mean
> for(i in 1:7)
+ {
+   mean_i<-mean(results11$v2[,i])
+   print(mean_i)
+ }
[1] 0.006522243
[1] -0.002555392
[1] 0.001728494
[1] 0.01655353
[1] -0.00568817
[1] -0.005687723
[1] 2.687769e-06
> #RMSE
> #install.packages("Metrics")
> library(Metrics)
> for(i in 1:7){
+   print(rmse(as.numeric(data[,i]),results11$v1[,i]))
+ }
[1] 0.05016585
[1] 0.01712463
[1] 0.02082737
[1] 0.1476998
[1] 0.08329551
[1] 0.06923529
[1] 4.172742e-05'
 
 
 
 