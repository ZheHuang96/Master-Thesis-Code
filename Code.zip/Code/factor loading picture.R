'This is the Nelson Sigel factor loadings
In this function, l is the constant decay parameter lambda, m is the maturity.'

Nelson.Siegel.factor.loadings <- function(l,m)
{
  column1 <- rep.int(1,length(m))
  column2 <- (1 - exp(-l * m))/(l * m)
  column3 <- column2 - exp(-l * m)
  
  lambmat <- cbind(column1,column2,column3)
  
  lambmat
}  

x<-seq(from=0, to=120)
f_1<- x^0
f_2<-(1 - exp(- 0.7144 * x))/( 0.7144 * x)
f_3<-(1 - exp(- 0.7144 * x))/( 0.7144 * x)- exp(- 0.7144 *x )
plot(x, f_1, type="l",xlim=c(0,120),ylim = c(0.0,1.0),xlab="Maturity(months)", ylab = "Loading")
lines(x, f_2, type="l")
lines(x, f_3, type="l")
text(x=c(60,60,25),y=c(0.9,0.4,0.2),labels = c("Level","Slope","Curvature"))
title(main="Factor Loadings", )
#axis(1,seq(0, 120, 20),seq(0, 120, 20))
f<-function(x) {
  f_3<-(1 - exp(- 0.7144 * x))/( 0.7144 * x)- exp(- 0.7144 *x )
  f_3
}
optimize(f,lower=3,upper=4)

#five factors
x<-seq(from=0, to=15)
f_1<- x^0
f_2<-(1 - exp(- 1.190 * x))/( 1.190 * x)
f_3<-(1 - exp(- 0.1021* x))/( 0.1021* x)
f_4<-(1 - exp(- 1.190 * x))/( 1.190 * x)- exp(- 1.190 *x )
f_5<-(1 - exp(- 0.1021* x))/( 0.1021* x)- exp(- 0.1021*x )
plot(x, f_1, type="l",xlim=c(0,15),ylim = c(0.0,1.0),xlab="Maturity(months)", ylab = "Loading")
lines(x, f_2, type="l",lty=3)
lines(x, f_3, type="l",lty=4)
lines(x, f_4, type="l",lty=5)
lines(x, f_5, type="l",lty=2)
#text(x=c(60,60,25),y=c(0.9,0.4,0.2),labels = c("Level","Slope","Curvature"))
title(main="DGNS Factor Loadings" )
x<-seq(from=0, to=120)
f_1<- x^0
f_2<-(1 - exp(- 2 * x))/( 2 * x)
f_3<-(1 - exp(- 0.01* x))/( 0.01 * x)
f_4<-(1 - exp(- 2 * x))/( 2 * x)- exp(- 2 *x )
f_5<-(1 - exp(- 0.01* x))/( 0.01* x)- exp(- 0.01*x )
plot(x, f_1, type="l",xlim=c(0,120),ylim = c(0.0,1.0),xlab="Maturity(months)", ylab = "Loading")
lines(x, f_2, type="l",lty=3)
lines(x, f_3, type="l",lty=4)
lines(x, f_4, type="l",lty=5)
lines(x, f_5, type="l",lty=2)
#text(x=c(60,60,25),y=c(0.9,0.4,0.2),labels = c("Level","Slope","Curvature"))
title(main="DGNS Factor Loadings" )
