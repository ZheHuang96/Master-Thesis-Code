Sys.setlocale("LC_TIME", "English")
#This is for the independent-factor DNS model
# Data
data<-read.csv("C:/Users/Huang Zhe/Desktop/thesis/code/Final thesis data.csv",header = TRUE, sep = ",")
require(xts)
data<- as.matrix(data[,which(names(data)=="X1M"):which(names(data)=="X120M")])
datas<- seq(as.Date("1996/1/1"), by = "month", length.out = 192)
data<- xts(data, order.by = datas)
#data1<- xts(data, order.by = datas) 


# Initial Parameters (According to Diebold& Rudebusch paper to initial Parameters)  
'Decay Parameter:constant Lambda= 0.0618,
Measurement Equation Error: diag H matrix (7x7) maturity=7,
Measurement Equation corrlated factor AR(1)coeffient matrix: matrix (3x3), 
VAR(1)mean: mu vector (3x1), 
State Equation Error:Q matrix (3x3). Total: 17 parameters
'
'
para<-c(0.6915,

        0.14170940,0.07289485,0.11492339,0.11120008,0.09055795,0.07672075,0.07222108,

0.08164287,0.2113579,1.232864,


4.5896,-1.9973,-1.1687,  

0.3408764,
0.02661018,1.08802059
 )'

#optim
para<-c(0.5196415324,
        
        0.0907774399,0.0003260778,0.0645333733,0.1148725016,0.2131866709,-0.0003023031,0.7561628396,
        
        0.0080925258, 0.0911462042, 0.0510383083,
        
        
        5.2524017349,-2.5457150668 ,-2.0330632093,  
        
        0.6896671239 ,
        0.9559969523,2.4386413880
)


prev<- FALSE # TRUE to Forecast.
ahead<-3 # X-step ahead forecast:3,6,12
lik <- FALSE # TRUE to return the value of the loglikelihood function. FALSE to return parameters.

# Kalman Filter function,in this function, l is the constant decay parameter lambda, m is the maturity.

kalman <- function(para,Y,lik,prev,ahead) {
  l<- para[1]
  m<- c(1/12,1/4,1/2,2,5,7,10)
  Months<-ahead 
  
  # Resize data if Forecast is on.
  
  if(prev){#*** Forecast
    T <- nrow(Y)
    Yf<-Y
    Yf[(T-Months+1):T,]<-NA
    Y<-Y[1:(T-Months),]
    T <- nrow(Y)
  }else{
    T <- nrow(Y)
    Yf = 1}#***
  #Pars contain all parameters in the estimation  
  pars<-list()
  W <- ncol(Y)
  #Three factors: L,S,C
  N <- 3
  
  # Create vectors and matrices
  
  pars$theta	<- matrix(NA,N,1) # Mean vector
  pars$Kappa<- diag(N) # Vector Autoregressive coeffient matrix VAR(1)	
  pars$H	<- diag(ncol(Y)) # Variance matrix of error
  pars$Sigma	<- diag(N) # Transition covariance matrix of error
  
  # Loading matrix
  
  source("C:\\Users\\Huang Zhe\\Desktop\\thesis\\code\\MyCode\\Nelson.Siegel.factor.loadings.R")
  pars$B	<- Nelson.Siegel.factor.loadings(l,m) 
  #yield adjustment term
  source("C:\\Users\\Huang Zhe\\Desktop\\thesis\\code\\MyCode\\yield.adjustment.term.R")
  pars$C<-yield.adjustment.term(sigma11=0.3408764,sigma12=0,sigma13=0,sigma21=0.02661018,sigma22=0,sigma23=0,sigma31=0,sigma32=0,sigma33=1.08802059,lambda=l,time=m)
  # Variance matrix of residuals
  
  for(i in 1:7){
    pars$H[i,i]<-para[1 + i]
  }
  
  H <- pars$H^2
  
  # Vector autoregressive coeffient matrix: VAR(1)
  pars$Kappa[1,1] <- -para[9]
  pars$Kappa[2,2] <- -para[10]
  pars$Kappa[3,3] <- -para[11]
  # Transition covariance matrix of residuals
  pars$Sigma[1,1] <- abs(para[15])
  pars$Sigma[2,2] <- abs(para[16])
  pars$Sigma[3,3] <- abs(para[17])
  # We start the filter at the unconditional mean and variance.
  pars$theta[1]<-para[12]
  pars$theta[2]<-para[13]
  pars$theta[3]<-para[14]
  
  # We calculate the conditional and unconditional covariance matrix
  sigmamat<-pars$Sigma
  kappamat<--pars$Kappa
  dt<-1/12
  # Step 1: diagonalize kappamat
  
  m<-eigen(kappamat)
  Eigenvalues<-m$values
  Eigenvectors<-m$vectors
  
  InvEigenvectors<-solve(Eigenvectors,diag(3))
  
  # Step 2: Calculate the S-overline matrix
  
  Smat<-InvEigenvectors%*%sigmamat%*%t(sigmamat)%*%t(InvEigenvectors)
  
  # Step 3: Calculate the V-overline matrix for dt and in the limit
  
  Vmat<-matrix(0,3,3)
  Vlim<-matrix(0,3,3)
  i<-1
  while(i<4)
  {
    j<-1
    while(j<4)
    {
      Vmat[i,j]<-Smat[i,j]*(1-exp(-(Eigenvalues[i]+Eigenvalues[j])*dt))/(Eigenvalues[i]+Eigenvalues[j])
      Vlim[i,j]<-Smat[i,j]/(Eigenvalues[i]+Eigenvalues[j])
      j<-j+1
    }
    i<-i+1
  }
  
  # Step 4: Calculate the final analytical covariance matrices
  
  Q<-Re(Eigenvectors%*%Vmat%*%t(Eigenvectors))
  
  Sigma<-Re(Eigenvectors%*%Vlim%*%t(Eigenvectors))
  # We calculate the conditional mean
  matrix.exponential<-function(mat=1,N=1)
  {
    size<-length(diag(mat))
    res1<-diag(size)
    res2<-res1
    i<-1
    while(i<N+1)
    {
      res2<-res2%*%(mat/i)
      res1<-res1+res2
      i<-i+1
    }
    res1
  }
  kappamatdt<--kappamat*dt
  Phi1<-matrix.exponential(mat=kappamatdt,N=100)
  Phi0<-(diag(3)-Phi1)%*%c(pars$theta[1],pars$theta[2],pars$theta[3])
  
  
 
  
  v1   <- matrix(NA,T,W)			  
  v2   <- matrix(NA,T,W) # Filtered errors: are defined as the difference between the observed yield curve and its filtered estimate from KF
  
  # Resize data if Forecast is on.
  if(prev){#*** 
    a.tt <- matrix(NA, (T+Months), N)
    a.t  <- matrix(NA, (T+Months+1), N) # if prev=TRUE, always will be dim(a.t)[1]=192
    P.tt <- array(NA, c((T+Months), N, N))
    P.t  <- array(NA, c((T+Months+1), N, N))
  }else{
    a.tt <- matrix(NA, T, N)
    a.t  <- matrix(NA, (T+1), N)
    P.tt <- array(NA, c(T, N, N))
    P.t  <- array(NA, c((T+1), N, N))
  }#***
  
  # Start state vector and variance matrix
  
  a.t[1, ]  <- pars$theta # Start state vector: pars$at0
  
  # Start variance matrix
  
  P.t[1, ,] <-Sigma # Start variance matrix. pars$Pt0
  
  # Initial log-likelihood	
  logLik <- - 0.5 * T * ncol(Y) * log(2 * pi)
  
  # Kalman Filter and log-likelihood
  source("C:\\Users\\Huang Zhe\\Desktop\\thesis\\code\\MyCode\\KfilterAFNS.R")  
  Kfilter(logLik=logLik,N=N,T=T,Y=Y,B=pars$B, C=pars$C,a.t=a.t,P.t=P.t,H=H,a.tt=a.tt,P.tt=P.tt,v2=v2,v1=v1,Kappa=pars$Kappa,theta=pars$theta,Q=Q,Phi0=Phi0,Phi1=Phi1, prev=prev,Months=Months,Yf=Yf,lik=lik)
}

results1<-kalman(para=para,Y=data,lik=lik,prev=prev,ahead=ahead) #**** 
results1

# $value -315.029 full sample loglik

# Numerical Optimization  
otim2<-optim(para,kalman,control = list(maxit=10000),Y=data,lik=lik,prev=prev,ahead=ahead)

# Parameters after optimization
'

'



#mean
for(i in 1:7)
{
  mean_i<-mean(results$v2[,i])
  print(mean_i)
}
#RMSE
#install.packages("Metrics")
library(Metrics)
for(i in 1:7){
  print(rmse(as.numeric(data[,i]),results$v1[,i]))
}
#forecast rmse
lik<-FALSE
prev<-TRUE
ahead<-12
results<-kalman(para=para,Y=data,lik=lik,prev=prev,ahead=ahead)
results
for(i in 1:7){
  print(rmse(as.numeric(data[,i]),results$Yf[,i]))
}
#factors
results$a.tt
Level_indep=ts(results$a.tt[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
