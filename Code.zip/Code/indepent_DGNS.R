Sys.setlocale("LC_TIME", "English")
#This is for the correlated-factor DNS model
# Data
data<-read.csv("C:/Users/Huang Zhe/Desktop/thesis/code/Final thesis data.csv",header = TRUE, sep = ",")
require(xts)
data<- as.matrix(data[,which(names(data)=="X1M"):which(names(data)=="X120M")])
datas<- seq(as.Date("1996/1/1"), by = "month", length.out = 192)
data<- xts(data, order.by = datas)

# Initial Parameters (See Dynamic-Nelson-Siegel to initial Parameters)  
# Lambda(2), H diag matrix (7), A matrix (5x5), mu vector (5x1), Q matrix (5x5). Total: 54 parameters

'para<-c(0.8912, 0.12,
        0.14170940,0.7289485,0.11492339,0.11120008,0.09055795,0.07672075,0.07222108,
          
        1.001605218,0.927345689,0.788078795,0.83207235,0.990209375,
          4.4539334622,-1.0504116702,-0.14, -1.0399574245,-0.13,
          
          -0.0001997376636,0.001747185840,
          0.000724688386,0.00344675961, 0.00425986914)'
#After optimization
para<-c(1.431623618,0.053015227,
        0.061426494,0.027062426,0.032672960,0.154021876,0.084835665,0.068776400,0.001670461,
        
        0.800344399,0.950563575,0.994038552,0.943785195,0.987980795,
        4.620794046,-1.073502237,-0.187954403, -1.420520051,-0.532330296,
        
        0.007409997,0.321823577,
        0.263363450,-0.360849458, 0.639470583)


prev<- FALSE # TRUE to Forecast
ahead<-12 # X-step ahead forecast
lik<-FALSE # # TRUE to return the value of the log-likelihood function. FALSE to return parameters.

# Kalman Filter function

kalman11<-function(para,Y,lik,prev,ahead){
  
 m <- c(1/12,1/4,1/2,2,5,7,10)  
 Months<-ahead

# Resize data if Forecast is on.
 if(prev){#*** Forecast
   T <- nrow(Y)
   Yf<-Y
   Yf[(T-Months+1):T,]<-NA
   Y<-Y[1:(T-Months),]
   T <- nrow(Y)
 }else{
   T <- nrow(Y)
   Yf<- 1}#***
  
  pars<-list()
  W <- ncol(Y)
  N <- 5
  
  # Create vectors and matrices
  pars$mu	<- matrix(NA,N,1)
  pars$A	<- diag(N)
  pars$H	<- diag(ncol(Y))
  pars$Q	<- diag(N)
  l1   <- para[1]
  l2   <- para[2]
  # Loading matrix
  
  factor.loadings <- function(l1,l2,m)
  {
    column1 <- rep.int(1,length(m))
    column2 <- (1 - exp(-l1 * m))/(l1 * m)
    column3 <- (1 - exp(-l2* m))/(l2 * m)
    column4 <- column2 - exp(-l1 * m)
    column5 <- column3 - exp(-l2 * m)
    lambmat <- cbind(column1,column2,column3,column4,column5)
    
    lambmat
  }  
  
  pars$B<- factor.loadings(l1=l1, l2=l2,m=m)
  
  # Variance matrix of residuals
  for(i in 1:7){
    pars$H[i,i]<-para[i+2]
  }
  
  H <- pars$H %*% pars$H
  
  # Vector autoregressive coeffient matrix: VAR(1)
  pars$A[1,1] <- para[10]
  pars$A[2,2] <- para[11]
  pars$A[3,3] <- para[12]
  pars$A[4,4] <- para[13]
  pars$A[5,5] <- para[14]
  
  # Mean vector
  pars$mu[1]<-para[15]
  pars$mu[2]<-para[16]
  pars$mu[3]<-para[17]
  pars$mu[4]<-para[18]
  pars$mu[5]<-para[19]
  
  # transition covariance matrix of residuals
  pars$Q[1,1] <- para[20]
  pars$Q[2,2] <- para[21]
  pars$Q[3,3] <- para[22]
  pars$Q[4,4] <- para[23]
  pars$Q[5,5] <- para[24]
  Q <- pars$Q %*% t(pars$Q) 
  
  v1   <- matrix(NA,T,W)			
  v2   <- matrix(NA,T,W)
  
  # Resize data if Forecast is on.
  if(prev){#*** 
    a.tt <- matrix(NA, (T+Months), N)
    a.t  <- matrix(NA, (T+Months+1), N) # if prev=TRUE, always will be dim(a.t)[1]=192
    P.tt <- array(NA, c((T+Months), N, N))
    P.t  <- array(NA, c((T+Months+1), N, N))
  }else{
    a.tt <- matrix(NA, T, N)
    a.t  <- matrix(NA, (T+1), N)
    P.tt <- array(NA, c(T, N, N))
    P.t  <- array(NA, c((T+1), N, N))
  }#***
  
  a.t[1, ]  <- pars$mu #pars$at0
  
  # Start variance matrix
  lyapunov<-function(N,A,Q){
    matrix(solve(diag(N^2) - kronecker(A,A)) %*% matrix(Q,(N^2),1),N,N)
  }  
  P.t[1, ,] <-lyapunov(N=N,A=pars$A,Q=Q) # Start variance matrix. pars$Pt0
  
  # Initial loglikelihood	  
  logLik <- - 0.5 * T * ncol(Y) * log(2 * pi)
  
  # Kalman Filter and log-likelihood
  source("C:\\Users\\Huang Zhe\\Desktop\\thesis\\code\\MyCode\\Kfilter.R")  
  Kfilter(logLik=logLik,N=N,T=T,Y=Y,B=pars$B,a.t=a.t,P.t=P.t,H=H,a.tt=a.tt,P.tt=P.tt,v2=v2,v1=v1,A=pars$A,mu=pars$mu,Q=Q,prev=prev,Months = Months,Yf=Yf,lik=lik)
}

results11<-kalman11(para=para,Y=data,lik=lik,prev=prev,ahead=ahead) 
results11
otim1<-optim(para,kalman11,control = list(maxit=1000000),Y=data,lik=lik,prev=prev,ahead=ahead)

#mean
for(i in 1:7)
{
  mean_i<-mean(results11$v2[,i])
  print(mean_i)
}
#RMSE
#install.packages("Metrics")
library(Metrics)
for(i in 1:7){
  print(rmse(as.numeric(data[,i]),results11$v1[,i]))
}
#forecast rmse
for(i in 1:7){
  print(rmse(as.numeric(data[,i]),results11$Yf[,i]))
}
  





lik<-TRUE
prev<-FALSE
results11<-kalman11(para=para,Y=data,lik=lik,prev=prev,ahead) 
results11


