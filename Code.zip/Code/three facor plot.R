#empirical three factors
Level_empirical=ts(Final_thesis_data$`120M`,frequency = 12,start = c(1996,1),end = c(2011,12))
Slope_empirical=ts(Slope,frequency = 12,start = c(1996,1),end = c(2011,12))
Curvature_empirical=ts(Curvature,frequency = 12,start = c(1996,1),end = c(2011,12))
#independent DNS
Level_indep=ts(results$a.tt[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
Slope_indep=ts(results$a.tt[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
Curvature_indep=ts(results$a.tt[,3],frequency = 12,start = c(1996,1),end = c(2011,12))
#correlated DNS
Level_correlated=ts(results$a.tt[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
Slope_correlated=ts(results$a.tt[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
Curvature_correlated=ts(results$a.tt[,3],frequency = 12,start = c(1996,1),end = c(2011,12))
#plot
#level
ts.plot(Level_empirical,Level_indep,Level_correlated,gpars = list(col=c("black","blue","red")))
title(main="The Empirical and Estimated level")
axis(1,seq(0, 200, 20),seq(0, 200, 20))
legend("topright",legend=c("Level_empirical","Level_indep","Level_correlated"),col=c("black","blue","red"),bty="n",lty =1)
#slope
ts.plot(Slope_empirical,Slope_indep,Slope_correlated,gpars = list(col=c("black","blue","red")))
title(main="The Empirical and Estimated Slope")
#axis(1,seq(1996, 2012, 1),seq(1996, 2012, 1))
legend("topright",legend=c("Slope_empirical","Slope_indep","Slope_correlated"),col=c("black","blue","red"),bty="n",lty =1)
#curvature
ts.plot(Curvature_empirical,Curvature_indep,Curvature_correlated,gpars = list(col=c("black","blue","red")))
title(main="The Empirical and Estimated curvature")
#axis(1,seq(1996, 2012, 1),seq(1996, 2012, 1))
legend("topright",legend=c("Curvature_empirical","Curvature_indep","Curvature_correlated"),col=c("black","blue","red"),bty="n",lty =1)