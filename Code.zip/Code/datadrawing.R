#install.packages("pastecs")
library(readr)
library(zoo)
library(xts)
library(YieldCurve)
library(pastecs)
library(readr)
Final_thesis_data <- read_csv("C:/Users/Huang Zhe/Desktop/thesis/code/Final thesis data.csv")
#data format English
Sys.setlocale("LC_TIME", "English")
#2D ts plot
x_1=ts(Final_thesis_data$`1M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_2=ts(Final_thesis_data$`3M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_3=ts(Final_thesis_data$`6M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_4=ts(Final_thesis_data$`24M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_5=ts(Final_thesis_data$`60M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_6=ts(Final_thesis_data$`84M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_7=ts(Final_thesis_data$`120M`,frequency = 12,start = c(1996,1),end = c(2011,12))
ts.plot(x_1,x_2,x_3,x_4,x_5,x_6,x_7,gpars = list(col=c("black","red","blue","green","gold","pink","purple","brown")))
title(main="Monthly Swedish yields from 1996 to 2011",ylab = "Yields(%)")
axis(1,seq(1996, 2012, 1),seq(1996, 2012, 1))
legend("topright",legend=c("1M","3M","6M","24M","60M","84M","120M"),col=c("black","red","blue","green","gold","pink","purple","brown"),bty="n",lty =1)

#Basic Statistics
stat.desc(x_1)
stat.desc(x_2)
stat.desc(x_3)
stat.desc(x_4)
stat.desc(x_5)
stat.desc(x_6)
stat.desc(x_7)
#Slope factor
Slope=(as.numeric(x_7)-as.numeric(x_2))/(-0.78)
stat.desc(Slope)
Slope_empirical=ts(Slope,frequency = 12,start = c(1996,1),end = c(2011,12))

#Curvature factor
Curvature=(2*as.numeric(x_4)-as.numeric(x_2)-as.numeric(x_7))
Curvature1=(2*as.numeric(x_4)-as.numeric(x_2)-as.numeric(x_7))/0.37
stat.desc(Curvature1)
Curvature_empirical=ts(Curvature,frequency = 12,start = c(1996,1),end = c(2011,12))
ts.plot(Curvature_t)

#ts_data=merge(x_1,x_2,x_3,x_4,x_5,x_6,x_7)
#data frame
R_1M=as.xts(x_1)
R_3M=as.xts(x_2)
R_6M=as.xts(x_3)
R_24M=as.xts(x_4)
R_60M=as.xts(x_5)
R_84M=as.xts(x_6)
R_120M=as.xts(x_7)
xts_data=merge.xts(R_1M,R_3M,R_6M,R_24M,R_60M,R_84M,R_120M)

'ns model
maturity <- c(1,3,6,24,60,84,120)
NSParameters <- Nelson.Siegel(rate=xts_data,	maturity=maturity)
str(NSParameters)
stat.desc(NSParameters$beta_0)
stat.desc(NSParameters$beta_1)
stat.desc(NSParameters$beta_2)
stat.desc(NSParameters$lambda)

plot(NSParameters$beta_0,major.format='%Y-%m',main ="Nelson-Sigel Model Level Factor", ,ylab = "Yields(%)")
plot(NSParameters$beta_1,major.format='%Y-%m',main ="Nelson-Sigel Model Slope Factor", ,ylab = "Yields(%)")
plot(NSParameters$beta_2,major.format='%Y-%m',main ="Nelson-Sigel Model Curvature Factor" ,ylab = "Yields(%)")
#xts_data1=merge.xts(R_1M,R_3M,R_6M,R_24M)
#NSParameters1 <- Nelson.Siegel(rate=xts_data1,maturity=c(1,3,6,24))
#NSParameters1
#max(NSParameters1$beta_2)


#y <- NSrates(NSParameters[5,], maturity.Fed)
#plot(maturity.Fed,FedYieldCurve[5,],main="Fitting Nelson-Siegel yield curve",
    # xlab=c("Pillars in months"), type="o")
#lines(maturity.Fed,y, col=2)
#legend("topleft",legend=c("observed yield curve","fitted yield curve"),
      # col=c(1,2),lty=1)


#3D'