install.packages("ggplot2")
install.packages("scales")
install.packages("devtools")
library(ggplot2)
library(scales)
library(devtools)
#data for each maturity
Y_1=data[,1]
Y_3=data[,2]
Y_6=data[,3]
Y_24=data[,4]
Y_60=data[,5]
Y_84=data[,6]
Y_120=data[,7]
Level_empirical<-Y_120
#7 maturities data
names(data) <- c("1M","3M","6M","24M","60M","84M","120M")
autoplot.zoo(data, facets=NULL)+labs(x="Date", y="Yields(%)", title="Months Swedish yields from 1996 to 2011")+scale_x_date(date_breaks = "3 year")

autoplot.zoo(data, facets=NULL)+labs(x="Date", y="Yields(%)")+scale_x_date(labels=date_format("%Y-%m"),date_breaks = "2 year")

#ggplot(Y_1,aes(x=index(Y_1),y=X1M))+geom_line()+ylab("Yields(%)")+xlab("Date")+ggtitle("Final weight, by diet")
#ggplot()+geom_line(data,aes(x=index(data),y=data$X1M))+geom_line(data,aes(x=index(data),y=data$X3M))+ylab("Yields(%)")+xlab("Date")

#DNS factor
#level
L_empirical<-Y_120
L_indep_DNS<-as.xts(results$a.tt[,1],order.by = datas)
L_corr_DNS<-as.xts(results2$a.tt[,1],order.by = datas)
DNS_L<-cbind(L_empirical, L_indep_DNS, L_corr_DNS)
names(DNS_L) <- c("L_empirical","L_indep","L_corr")
autoplot.zoo(DNS_L, facets=NULL, show.legend = FALSE)+labs(x="Date")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels =c("L_empirical","L_indep","L_corr"),values = c(1,1,5)) +scale_size_manual(labels =c("L_empirical","L_indep","L_corr"),values = c(1, 1.2, 1))
#+geom_line(size=1.2)+aes(linetype = Series)
#+scale_size_manual(values = c(1,5,2))+scale_linetype_manual(values = c(1,1,2)) 
#slope
S_empirical<-as.xts(Slope,order.by = datas)
S_indep_DNS<-as.xts(results$a.tt[,2],order.by = datas)
S_corr_DNS<-as.xts(results2$a.tt[,2],order.by = datas)
DNS_S<-cbind(S_empirical, S_indep_DNS, S_corr_DNS)
names(DNS_S) <- c("S_empirical","S_indep","S_corr")
autoplot.zoo(DNS_S, facets=NULL, show.legend = FALSE)+labs(x="Date")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels =c("S_empirical","S_indep","S_corr"),values = c(1,1,5)) +scale_size_manual(labels =c("S_empirical","S_indep","S_corr"),values = c(1, 1.2, 1)) 
#curvature
C_empirical<-as.xts(Curvature1,order.by = datas)
C_indep_DNS<-as.xts(results$a.tt[,3],order.by = datas)
C_corr_DNS<-as.xts(results2$a.tt[,3],order.by = datas)
DNS_C<-cbind(C_empirical, C_indep_DNS, C_corr_DNS)
names(DNS_C) <- c("C_empirical","C_indep","C_corr")
autoplot.zoo(DNS_C, facets=NULL, show.legend = FALSE)+labs(x="Date")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels =c("S_empirical","S_indep","S_corr"),values = c(1,1,5)) +scale_size_manual(labels =c("C_empirical","C_indep","C_corr"),values = c(1, 1.2, 1)) 
 
#compared data
require(gridExtra)
Y_indep_1<-as.xts(results$v1[,1],order.by = datas)
Y_corr_1<-as.xts(results2$v1[,1],order.by = datas)
Yields_1<-cbind(Y_1,Y_indep_1,Y_corr_1)
names(Yields_1) <- c("Y_1","Y_indep_1","Y_corr_1")
D1<-autoplot.zoo(Yields_1, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="1M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels =c("Y_1","Y_indep_1","Y_corr_1"),values = c(1,1,5)) +scale_size_manual(labels =c("Y_1","Y_indep_1","Y_corr_1"),values = c(1.8, 1.2, 1))  
Y_indep_3<-as.xts(results$v1[,2],order.by = datas)
Y_corr_3<-as.xts(results2$v1[,2],order.by = datas)
Yields_3<-cbind(Y_3,Y_indep_3,Y_corr_3)
names(Yields_3) <- c("Y_3","Y_indep_3","Y_corr_3")
D3<-autoplot.zoo(Yields_3, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="3M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels =c("Y_3","Y_indep_3","Y_corr_3"),values = c(1,1,5)) +scale_size_manual(labels =c("Y_3","Y_indep_3","Y_corr_3"),values = c(2.2, 1.2, 1))  
Y_indep_6<-as.xts(results$v1[,3],order.by = datas)
Y_corr_6<-as.xts(results2$v1[,3],order.by = datas)
Yields_6<-cbind(Y_6,Y_indep_6,Y_corr_6)
names(Yields_6) <- c("Y_6","Y_indep_6","Y_corr_6")
D6<-autoplot.zoo(Yields_6, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="6M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_6","Y_indep_6","Y_corr_6"),values = c(1,1,5)) +scale_size_manual(labels = c("Y_6","Y_indep_6","Y_corr_6"),values = c(1.8, 1.2, 1))
Y_indep_24<-as.xts(results$v1[,4],order.by = datas)
Y_corr_24<-as.xts(results2$v1[,4],order.by = datas)
Yields_24<-cbind(Y_24,Y_indep_24,Y_corr_24)
names(Yields_24) <- c("Y_24","Y_indep_24","Y_corr_24")
D24<-autoplot.zoo(Yields_24, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="24M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_24","Y_indep_24","Y_corr_24"),values = c(1,1,5)) +scale_size_manual(labels = c("Y_24","Y_indep_24","Y_corr_24"),values = c(1.5, 1.2, 1))
Y_indep_60<-as.xts(results$v1[,5],order.by = datas)
Y_corr_60<-as.xts(results2$v1[,5],order.by = datas)
Yields_60<-cbind(Y_60,Y_indep_60,Y_corr_60)
names(Yields_60) <- c("Y_60","Y_indep_60","Y_corr_60")
D60<-autoplot.zoo(Yields_60, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="60M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_60","Y_indep_60","Y_corr_60"),values = c(1,1,5)) +scale_size_manual(labels = c("Y_60","Y_indep_60","Y_corr_60"),values = c(2.2, 1.2, 1))
Y_indep_84<-as.xts(results$v1[,6],order.by = datas)
Y_corr_84<-as.xts(results2$v1[,6],order.by = datas)
Yields_84<-cbind(Y_84,Y_indep_84,Y_corr_84)
names(Yields_84) <- c("Y_84","Y_indep_84","Y_corr_84")
D84<-autoplot.zoo(Yields_84, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="84M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_84","Y_indep_84","Y_corr_84"),values = c(1,1,5)) +scale_size_manual(labels = c("Y_84","Y_indep_84","Y_corr_84"),values = c(2.2, 1.2, 1))
Y_indep_120<-as.xts(results$v1[,7],order.by = datas)
Y_corr_120<-as.xts(results2$v1[,7],order.by = datas)
Yields_120<-cbind(Y_120,Y_indep_120,Y_corr_120)
names(Yields_120) <- c("Y_120","Y_indep_120","Y_corr_120")
D120<-autoplot.zoo(Yields_120, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="120M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_120","Y_indep_120","Y_corr_120"),values = c(1,1,5)) +scale_size_manual(labels = c("Y_120","Y_indep_120","Y_corr_120"),values = c(2.2, 1.2, 1))
#AFNS

grid.arrange(D1, D3, D6, D24,D60, D84, D120, ncol=1)













#AFNS
#level
L_empirical<-Y_120
L_indep_AFNS<-as.xts(results1$a.tt[,1],order.by = datas)
L_corr_AFNS<-as.xts(results3$a.tt[,1],order.by = datas)
AFNS_L<-cbind(L_empirical, L_indep_AFNS, L_corr_AFNS)
names(AFNS_L) <- c("L_empirical","L_indep","L_corr")
autoplot.zoo(AFNS_L, facets=NULL,show.legend = FALSE)+labs(x="Date")+aes(linetype = Series,size = Series)+scale_linetype_manual(labels =c("L_empirical","L_indep","L_corr"),values = c(1,1,5)) +scale_size_manual(labels =c("L_empirical","L_indep","L_corr"),values = c(1, 1, 1)) 
#slope
S_empirical<-as.xts(Slope,order.by = datas)
S_indep_AFNS<-as.xts(results1$a.tt[,2],order.by = datas)
S_corr_AFNS<-as.xts(results3$a.tt[,2],order.by = datas)
AFNS_S<-cbind(S_empirical, S_indep_AFNS, S_corr_AFNS)
names(AFNS_S)<-c("S_empirical","S_indep","S_corr")
autoplot.zoo(AFNS_S, facets=NULL,show.legend = FALSE)+labs(x="Date")+aes(linetype = Series,size = Series)+scale_linetype_manual(labels =c("S_empirical","S_indep","S_corr"),values = c(1,1,5)) +scale_size_manual(labels =c("S_empirical","S_indep","S_corr"),values = c(1, 1, 1))  
#curvature
C_empirical<-as.xts(Curvature1,order.by = datas)
C_indep_AFNS<-as.xts(results1$a.tt[,3],order.by = datas)
C_corr_AFNS<-as.xts(results3$a.tt[,3],order.by = datas)
AFNS_C<-cbind(C_empirical, C_indep_AFNS, C_corr_AFNS)
names(AFNS_C)<-c("C_empirical","C_indep","C_corr")
autoplot.zoo(AFNS_C, facets=NULL, show.legend = FALSE)+labs(x="Date")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels =c("S_empirical","S_indep","S_corr"),values = c(1,1,5)) +scale_size_manual(labels =c("C_empirical","C_indep","C_corr"),values = c(1, 1, 1)) 
#compaerd data
Y_indep_1<-as.xts(results1$v1[,1],order.by = datas)
Y_corr_1<-as.xts(results3$v1[,1],order.by = datas)
Yields_1<-cbind(Y_1,Y_indep_1,Y_corr_1)
names(Yields_1) <- c("Y_1","Y_indep_1","Y_corr_1")
D1<-autoplot.zoo(Yields_1, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="1M Yields(%)")+aes(linetype = Series,size = Series)+scale_linetype_manual(labels =c("Y_1","Y_indep_1","Y_corr_1"),values = c(1,1,5)) +scale_size_manual(labels =c("Y_1","Y_indep_1","Y_corr_1"),values = c(1.8, 1.2, 1))   
Y_indep_3<-as.xts(results1$v1[,2],order.by = datas)
Y_corr_3<-as.xts(results3$v1[,2],order.by = datas)
names(Yields_3) <- c("Y_3","Y_indep_3","Y_corr_3")
D3<-autoplot.zoo(Yields_3, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="3M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels =c("Y_3","Y_indep_3","Y_corr_3"),values = c(1,1,5)) +scale_size_manual(labels =c("Y_3","Y_indep_3","Y_corr_3"),values = c(2.4, 1.2, 1))  
Y_indep_6<-as.xts(results1$v1[,3],order.by = datas)
Y_corr_6<-as.xts(results3$v1[,3],order.by = datas)
Yields_6<-cbind(Y_6,Y_indep_6,Y_corr_6)
names(Yields_6) <- c("Y_6","Y_indep_6","Y_corr_6")
D6<-autoplot.zoo(Yields_6, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="6M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_6","Y_indep_6","Y_corr_6"),values = c(1,1,5)) +scale_size_manual(labels = c("Y_6","Y_indep_6","Y_corr_6"),values = c(1.8, 1.2, 1))
Y_indep_24<-as.xts(results1$v1[,4],order.by = datas)
Y_corr_24<-as.xts(results3$v1[,4],order.by = datas)
Yields_24<-cbind(Y_24,Y_indep_24,Y_corr_24)
names(Yields_24) <- c("Y_24","Y_indep_24","Y_corr_24")
D24<-autoplot.zoo(Yields_24, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="24M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_24","Y_indep_24","Y_corr_24"),values = c(1,1,5)) +scale_size_manual(labels = c("Y_24","Y_indep_24","Y_corr_24"),values = c(1.5, 1.2, 1))
Y_indep_60<-as.xts(results1$v1[,5],order.by = datas)
Y_corr_60<-as.xts(results3$v1[,5],order.by = datas)
Yields_60<-cbind(Y_60,Y_indep_60,Y_corr_60)
names(Yields_60) <- c("Y_60","Y_indep_60","Y_corr_60")
D60<-autoplot.zoo(Yields_60, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="60M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_60","Y_indep_60","Y_corr_60"),values = c(1,1,5)) +scale_size_manual(labels = c("Y_60","Y_indep_60","Y_corr_60"),values = c(1, 1.2, 1))
Y_indep_84<-as.xts(results1$v1[,6],order.by = datas)
Y_corr_84<-as.xts(results3$v1[,6],order.by = datas)
Yields_84<-cbind(Y_84,Y_indep_84,Y_corr_84)
names(Yields_84) <- c("Y_84","Y_indep_84","Y_corr_84")
D84<-autoplot.zoo(Yields_84, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="84M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_84","Y_indep_84","Y_corr_84"),values = c(1,1,5)) +scale_size_manual(labels = c("Y_84","Y_indep_84","Y_corr_84"),values = c(1, 1.2, 1))
Y_indep_120<-as.xts(results1$v1[,7],order.by = datas)
Y_corr_120<-as.xts(results3$v1[,7],order.by = datas)
Yields_120<-cbind(Y_120,Y_indep_120,Y_corr_120)
names(Yields_120) <- c("Y_120","Y_indep_120","Y_corr_120")
D120<-autoplot.zoo(Yields_120, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="120M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_120","Y_indep_120","Y_corr_120"),values = c(1,1,5)) +scale_size_manual(labels = c("Y_120","Y_indep_120","Y_corr_120"),values = c(1, 1.2, 1))
grid.arrange(D1, D3, D6, D24, D60, D84,D120, ncol=1)

#DGNS
Y_indep_1<-as.xts(results11$v1[,1],order.by = datas)
Yields_1<-cbind(Y_1,Y_indep_1)
names(Yields_1) <- c("Y_1","Y_indep_1")
D1<-autoplot.zoo(Yields_1, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="1M Yields(%)")+aes(linetype = Series,size = Series)+scale_linetype_manual(labels =c("Y_1","Y_indep_1"),values = c(1,1)) +scale_size_manual(labels =c("Y_1","Y_indep_1"),values = c(1.8, 1))   
Y_indep_3<-as.xts(results11$v1[,2],order.by = datas)
Yields_3<-cbind(Y_3,Y_indep_3)
names(Yields_3) <- c("Y_3","Y_indep_3")
D3<-autoplot.zoo(Yields_3, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="3M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels =c("Y_3","Y_indep_3"),values = c(1,1)) +scale_size_manual(labels =c("Y_3","Y_indep_3"),values = c(1.8, 1))  
Y_indep_6<-as.xts(results1$v1[,3],order.by = datas)
Yields_6<-cbind(Y_6,Y_indep_6)
names(Yields_6) <- c("Y_6","Y_indep_6")
D6<-autoplot.zoo(Yields_6, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="6M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_6","Y_indep_6"),values = c(1,1)) +scale_size_manual(labels = c("Y_6","Y_indep_6"),values = c(1.8, 1))
Y_indep_24<-as.xts(results11$v1[,4],order.by = datas)
Yields_24<-cbind(Y_24,Y_indep_24)
names(Yields_24) <- c("Y_24","Y_indep_24")
D24<-autoplot.zoo(Yields_24, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="24M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_24","Y_indep_24"),values = c(1,1)) +scale_size_manual(labels = c("Y_24","Y_indep_24"),values = c(1.5,1))
Y_indep_60<-as.xts(results11$v1[,5],order.by = datas)
Yields_60<-cbind(Y_60,Y_indep_60)
names(Yields_60) <- c("Y_60","Y_indep_60")
D60<-autoplot.zoo(Yields_60, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="60M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_60","Y_indep_60"),values = c(1,1)) +scale_size_manual(labels = c("Y_60","Y_indep_60"),values = c(1.5, 1))
Y_indep_84<-as.xts(results11$v1[,6],order.by = datas)
Yields_84<-cbind(Y_84,Y_indep_84)
names(Yields_84) <- c("Y_84","Y_indep_84")
D84<-autoplot.zoo(Yields_84, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="84M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_84","Y_indep_84"),values = c(1,1)) +scale_size_manual(labels = c("Y_84","Y_indep_84"),values = c(1.5,1))
Y_indep_120<-as.xts(results11$v1[,7],order.by = datas)
Yields_120<-cbind(Y_120,Y_indep_120)
names(Yields_120) <- c("Y_120","Y_indep_120")
D120<-autoplot.zoo(Yields_120, facets=NULL,show.legend = FALSE)+labs(x="Date",  y="120M Yields(%)")+aes(linetype = Series,size = Series) +scale_linetype_manual(labels = c("Y_120","Y_indep_120"),values = c(1,1)) +scale_size_manual(labels = c("Y_120","Y_indep_120"),values = c(1.8, 1))
grid.arrange(D1, D3, D6, D24, D60, D84,D120, ncol=1)

