para<-c(0.4976832,
        
        0.08948249,-0.0002589272,-0.06439215,0.1321366,0.2675300,0.02792323,1.119943,
        
        0.1236103, -0.3346683,0.3225620, -0.2236299,0.4007232,-0.6014589,0.7017006,0.03921358,0.5886448,
        
        
        5.210027,-2.493774,-1.997708,  
        
        0.6157363,
        -2.137208e-07, 0.8074943,-0.5496068,0.5599663,2.198935
)
pars<-list()
pars$Kappa<- diag(3)
pars$Sigma	<- diag(3)
pars$Kappa[1,1] <- -para[9]
pars$Kappa[1,2] <- -para[10]
pars$Kappa[1,3] <- -para[11]
pars$Kappa[2,1] <- -para[12]
pars$Kappa[2,2] <- -para[13]
pars$Kappa[2,3] <- -para[14]
pars$Kappa[3,1] <- -para[15]
pars$Kappa[3,2] <- -para[16]
pars$Kappa[3,3] <- -para[17]
# Transition covariance matrix of residuals
pars$Sigma[1,1] <- abs(para[21])
pars$Sigma[2,1] <- abs(para[22])
pars$Sigma[2,2] <- abs(para[23])
pars$Sigma[3,1] <- abs(para[24])
pars$Sigma[3,2] <- abs(para[25])
pars$Sigma[3,3] <- abs(para[26])


sigmamat<-pars$Sigma
kappamat<--pars$Kappa
dt<-1/12
# Step 1: diagonalize kappamat

m<-eigen(kappamat)
Eigenvalues<-m$values
Eigenvectors<-m$vectors

InvEigenvectors<-solve(Eigenvectors,diag(3))

# Step 2: Calculate the S-overline matrix

Smat<-InvEigenvectors%*%sigmamat%*%t(sigmamat)%*%t(InvEigenvectors)

# Step 3: Calculate the V-overline matrix for dt and in the limit

Vmat<-matrix(0,3,3)
Vlim<-matrix(0,3,3)
i<-1
while(i<4)
{
  j<-1
  while(j<4)
  {
    Vmat[i,j]<-Smat[i,j]*(1-exp(-(Eigenvalues[i]+Eigenvalues[j])*dt))/(Eigenvalues[i]+Eigenvalues[j])
    Vlim[i,j]<-Smat[i,j]/(Eigenvalues[i]+Eigenvalues[j])
    j<-j+1
  }
  i<-i+1
}

# Step 4: Calculate the final analytical covariance matrices

Q<-Re(Eigenvectors%*%Vmat%*%t(Eigenvectors))

Sigma<-Re(Eigenvectors%*%Vlim%*%t(Eigenvectors))