
Sys.setlocale("LC_TIME", "English")
#This is for the correlated-factor DNS model
# Data
data<-read.csv("C:/Users/Huang Zhe/Desktop/thesis/code/Final thesis data.csv",header = TRUE, sep = ",")
require(xts)
data<- as.matrix(data[,which(names(data)=="X1M"):which(names(data)=="X120M")])
datas<- seq(as.Date("1996/1/1"), by = "month", length.out = 192)
data<- xts(data, order.by = datas)

# Initial Parameters (See Dynamic-Nelson-Siegel to initial Parameters)  
# Lambda(2), H diag matrix (7), A matrix (5x5), mu vector (5x1), Q matrix (5x5). Total: 54 parameters

para<-c(1.431623618,0.53015227,
        0.061426494,0.027062426,0.032672960,0.154021876,0.084835665,0.068776400,0.001670461,
          
        0.91605218,0.032684878,0.27546959,0.09417855,0.28699387,
        0.08057180,0.627345689,0.080668263,0.27995407,0.788078795,
        0.036720125,0.064640757,0.789410433,0.028201668, 0.1007201873,
        0.010575874,0.023509296,0.037788015,0.913207235,0.269708016,
        0.1288524727,0.071893724,0.0433801272,0.8930209375,0.7409997,
        4.620794046,-1.073502237,-0.187954403, -0.420520051,-0.253233029,
          
          0.001997376636,
          0.0166087651, 0.0174718584,
          -0.01314576674,0.097595869,0.06724688386,
        -0.0302120250,-0.0344675961,0.0373388285,0.00639470583,
        0.0425986914,0.0369501881,0.152326423,0.704075030,-0.0373388285,0.0677)


prev<- FALSE # TRUE to Forecast
ahead<-12 # X-step ahead forecast
lik<-TRUE # # TRUE to return the value of the log-likelihood function. FALSE to return parameters.

# Kalman Filter function

kalman11<-function(para,Y,lik,prev,ahead){
  
  m <- c(1/12,1/4,1/2,2,5,7,10)  
 Months<-ahead#***
  
  # Resize data if Forecast is on.
  if(prev){#***
    T <- nrow(Y)
    Yf<-Y
    Yf[(T-Months+1):T,]<-NA
    Y<-Y[1:(T-Months),]
    T <- nrow(Y)
  }else{
    T <- nrow(Y)
    Yf<-1
  }#***
  
  pars<-list()
  W <- ncol(Y)
  N <- 5
  
  # Create vectors and matrices
  pars$mu	<- matrix(NA,N,1)
  pars$A	<- diag(N)
  pars$H	<- diag(ncol(Y))
  pars$Q	<- diag(N)
  l1   <- para[1]
  l2   <- para[2]
  # Loading matrix
  
  factor.loadings <- function(l1,l2,m)
  {
    column1 <- rep.int(1,length(m))
    column2 <- (1 - exp(-l1 * m))/(l1 * m)
    column3 <- (1 - exp(-l2* m))/(l2 * m)
    column4 <- column2 - exp(-l1 * m)
    column5 <- column3 - exp(-l2 * m)
    lambmat <- cbind(column1,column2,column3,column4,column5)
    
    lambmat
  }  
  
  pars$B<- factor.loadings(l1=l1, l2=l2,m=m)
  
  # Variance matrix of residuals
  for(i in 1:7){
    pars$H[i,i]<-para[i+2]
  }
  
  H <- pars$H %*% pars$H
  
  # Vector autoregressive coeffient matrix: VAR(1)
  pars$A[1,1] <- para[10]
  pars$A[1,2] <- para[11]
  pars$A[1,3] <- para[12]
  pars$A[1,4] <- para[13]
  pars$A[1,5] <- para[14]
  pars$A[2,1] <- para[15]
  pars$A[2,2] <- para[16]
  pars$A[2,3] <- para[17]
  pars$A[2,4] <- para[18]
  pars$A[2,5] <- para[19]
  pars$A[3,1] <- para[20]
  pars$A[3,2] <- para[21]
  pars$A[3,3] <- para[22]
  pars$A[3,4] <- para[23]
  pars$A[3,5] <- para[24]
  pars$A[4,1] <- para[25]
  pars$A[4,2] <- para[26]
  pars$A[4,3] <- para[27]
  pars$A[4,4] <- para[28]
  pars$A[4,5] <- para[29]
  pars$A[5,1] <- para[30]
  pars$A[5,2] <- para[31]
  pars$A[5,3] <- para[32]
  pars$A[5,4] <- para[33]
  pars$A[5,5] <- para[34]
  # Mean vector
  pars$mu[1]<-para[35]
  pars$mu[2]<-para[36]
  pars$mu[3]<-para[37]
  pars$mu[4]<-para[38]
  pars$mu[5]<-para[39]
  
  # transition covariance matrix of residuals
  pars$Q[1,1] <- para[40]
  pars$Q[2,1] <- para[41]
  pars$Q[2,2] <- para[42]
  pars$Q[3,1] <- para[43]
  pars$Q[3,2] <- para[44]
  pars$Q[3,3] <- para[45]
  pars$Q[4,1] <- para[46]
  pars$Q[4,2] <- para[47]
  pars$Q[4,3] <- para[48]
  pars$Q[4,4] <- para[49]
  pars$Q[5,1] <- para[50]
  pars$Q[5,2] <- para[51]
  pars$Q[5,3] <- para[52]
  pars$Q[5,4] <- para[53]
  pars$Q[5,5] <- para[54]
  Q <- pars$Q %*% t(pars$Q) 
  
  v1   <- matrix(NA,T,W)			
  v2   <- matrix(NA,T,W)
  
  # Resize data if Forecast is on.
  if(prev){#***
    a.tt <- matrix(NA, (T+Months), N)
    a.t  <- matrix(NA, (T+Months+1), N) # if prev=TRUE, always will be dim(a.t)[1]=348
    P.tt <- array(NA, c((T+Months), N, N))
    P.t  <- array(NA, c((T+Months+1), N, N))
  }else{
    a.tt <- matrix(NA, T, N)
    a.t  <- matrix(NA, (T+1), N)
    P.tt <- array(NA, c(T, N, N))
    P.t  <- array(NA, c((T+1), N, N))
  }#***
  
  a.t[1, ]  <- pars$mu #pars$at0
  
  # Start variance matrix
  lyapunov<-function(N,A,Q){
    matrix(solve(diag(N^2) - kronecker(A,A)) %*% matrix(Q,(N^2),1),N,N)
  }  
  P.t[1, ,] <-lyapunov(N=N,A=pars$A,Q=Q) # Start variance matrix. pars$Pt0
  
  # Initial loglikelihood	  
  logLik <- - 0.5 * T * ncol(Y) * log(2 * pi)
  
  # Kalman Filter and log-likelihood
  source("C:\\Users\\Huang Zhe\\Desktop\\thesis\\code\\MyCode\\Kfilter.R")  
  Kfilter(logLik=logLik,N=N,T=T,Y=Y,B=pars$B,a.t=a.t,P.t=P.t,H=H,a.tt=a.tt,P.tt=P.tt,v2=v2,v1=v1,A=pars$A,mu=pars$mu,Q=Q,prev=prev,Months=Months,Yf=Yf,lik=lik)
}

results11<-kalman11(para=para,Y=data,lik=lik,prev=prev,ahead=ahead) 
results11
otim1<-optim(para,kalman,control = list(maxit=1000000),Y=data,lik=lik,prev=prev,ahead=ahead)
# -1839.368

#  Numerical Optimization  

#  Nelder-Mead

'
otim <- optim(par=para,fn=kalman1,Y=data,lik=lik,gr=NULL,method="Nelder-Mead",
control=list(trace=2,REPORT=2,maxit=10000000),hessian = FALSE)
'


lik<-TRUE
prev<-FALSE
results11<-kalman11(para=para,Y=data,lik=lik,prev=prev,ahead) 
results11

# -3678.985 full sample
