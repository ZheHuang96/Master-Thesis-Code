q_indepent<-diag(3)
q_indepent[1,1] <- 0.1987905905
q_indepent[2,2] <-  0.2920134517
q_indepent[3,3] <- 0.5947249283
Q_indepent <- q_indepent %*% t(q_indepent) 

Q_indepent

q_correlated<-diag(3)
q_correlated[1,1] <- 0.1997376636
q_correlated[2,1] <- -0.1660876512
q_correlated[2,2] <-  0.1747185840
q_correlated[3,1] <- -0.1314576674
q_correlated[3,2] <- -0.0097595869
q_correlated[3,3] <- 0.6724688386
Q_correlated <- q_correlated %*% t(q_correlated) 

Q_correlated
