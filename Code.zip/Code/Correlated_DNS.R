Sys.setlocale("LC_TIME", "English")
#This is for the correlated-factor DNS model
# Data
data<-read.csv("C:/Users/Huang Zhe/Desktop/thesis/code/Final thesis data.csv",header = TRUE, sep = ",")
require(xts)
data<- as.matrix(data[,which(names(data)=="X1M"):which(names(data)=="X120M")])
datas<- seq(as.Date("1996/1/1"), by = "month", length.out = 192)
data<- xts(data, order.by = datas)



# Initial Parameters (According to Diebold& Rudebusch paper to initial Parameters)  
'Decay Parameter:constant Lambda= 0.0618,
Measurement Equation Error: diag H matrix (7x7) maturity=7,
Measurement Equation corrlated factor VAR(1)coeffient matrix:A matrix (3x3), 
VAR(1)mean: mu vector (3x1), 5.0803,-2.0691,-1.7491,  
State Equation Error:Q matrix (3x3). Total: 26 parameters
'
'para<-c(0.0618,

0.14170940,0.07289485,0.11492339,0.11120008,0.09055795,0.07672075,0.07222108,

 0.99010443,0.02496842,-0.002294319,
-0.02812401,0.94256154, 0.028699387,
 0.05178493,0.01247332, 0.788078795, 
5.0803,-2.0691,-1.7491,

 0.3408764,
-0.07882772,0.02661018,
 0.21351036,0.00425989,1.08802059)'

#parameters after optimization

para<-c(0.6913479229,
        
        -0.0942069355,-0.0008959076,-0.0651823693,0.1471329772,0.0716193590,-0.0872799999,-0.0148008074,
        
        1.0270623234,0.0269708016,-0.0186334194,
        -0.0433801272,0.8930209375, 0.1007201873,
        -0.1288524727,-0.0071893724, 1.0052167449 , 
        
        4.4539334622,-2.4504116702, -1.3399574245,
        
        0.1997376636,
        -0.1660876512, 0.1747185840,
        -0.1314576674,-0.0097595869,0.6724688386)

prev<- FALSE # TRUE to Forecast.
ahead<-3 # X-step ahead forecast
lik <- FALSE # TRUE to return the value of the loglikelihood function. FALSE to return parameters.

# Kalman Filter function,in this function, l is the constant decay parameter lambda, m is the maturity.

kalman <- function(para,Y,lik,prev,ahead) 
{
l<- para[1]
m<- c(1/12,1/4,1/2,2,5,7,10)
Months<-ahead 
  
# Resize data if Forecast is on.

  if(prev){#*** Forecast
		  T <- nrow(Y)
		  Yf<-Y
		  Yf[(T-Months+1):T,]<-NA
		  Y<-Y[1:(T-Months),]
		  T <- nrow(Y)
  }else{
		  T <- nrow(Y)
		  Yf = 1}#***
#Pars contain all parameters in the estimation  
pars<-list()
W <- ncol(Y)
#Three factors: L,S,C
N <- 3
  
# Create vectors and matrices

pars$mu	<- matrix(NA,N,1) # Mean vector
pars$A<- diag(N) # Vector Autoregressive coeffient matrix VAR(1)	
pars$H	<- diag(ncol(Y)) # Variance matrix of error
pars$Q	<- diag(N) # Transition covariance matrix of error

# Loading matrix

source("C:\\Users\\Huang Zhe\\Desktop\\thesis\\code\\MyCode\\Nelson.Siegel.factor.loadings.R")
pars$B	<- Nelson.Siegel.factor.loadings(l,m) 
  
# Variance matrix of residuals

  for(i in 1:7){
    pars$H[i,i]<-para[1 + i]
  }

H <- pars$H^2
  
# Vector autoregressive coeffient matrix: VAR(1)
pars$A[1,1] <- para[9]
pars$A[1,2] <- para[10]
pars$A[1,3] <- para[11]
pars$A[2,1] <- para[12]
pars$A[2,2] <- para[13]
pars$A[2,3] <- para[14]
pars$A[3,1] <- para[15]
pars$A[3,2] <- para[16]
pars$A[3,3] <- para[17]
  
# Mean vector
pars$mu[1]<-para[18]
pars$mu[2]<-para[19]
pars$mu[3]<-para[20]
  
# Transition covariance matrix of residuals
pars$Q[1,1] <- para[21]
pars$Q[2,1] <- para[22]
pars$Q[2,2] <- para[23]
pars$Q[3,1] <- para[24]
pars$Q[3,2] <- para[25]
pars$Q[3,3] <- para[26]
#Q=qq' 
Q <- pars$Q %*% t(pars$Q) 

v1   <- matrix(NA,T,W)			  
v2   <- matrix(NA,T,W) # Filtered errors: are defined as the difference between the observed yield curve and its filtered estimate from KF
  
# Resize data if Forecast is on.
  if(prev){#*** 
	  a.tt <- matrix(NA, (T+Months), N)
	  a.t  <- matrix(NA, (T+Months+1), N) # if prev=TRUE, always will be dim(a.t)[1]=192
	  P.tt <- array(NA, c((T+Months), N, N))
	  P.t  <- array(NA, c((T+Months+1), N, N))
  }else{
	  a.tt <- matrix(NA, T, N) #latent factor X
	  a.t  <- matrix(NA, (T+1), N)
	  P.tt <- array(NA, c(T, N, N))
	  P.t  <- array(NA, c((T+1), N, N))
  }#***
  
# Start state vector and variance matrix
a.t[1, ]  <- pars$mu # Start state vector: pars$at0

# Start variance matrix
lyapunov<-function(N,A,Q){
  matrix(solve(diag(N^2) - kronecker(A,A)) %*% matrix(Q,(N^2),1),N,N)
}
P.t[1, ,] <-lyapunov(N=N,A=pars$A,Q=Q) # Start variance matrix. pars$Pt0
  
# Initial log-likelihood	
logLik <- - 0.5 * T * ncol(Y) * log(2 * pi)

# Kalman Filter and log-likelihood
source("C:\\Users\\Huang Zhe\\Desktop\\thesis\\code\\MyCode\\Kfilter.R")  
Kfilter(logLik=logLik,N=N,T=T,Y=Y,B=pars$B,a.t=a.t,P.t=P.t,H=H,a.tt=a.tt,P.tt=P.tt,v2=v2,v1=v1,A=pars$A,mu=pars$mu,Q=Q,prev=prev,Months=Months,Yf=Yf,lik=lik)
}

results2<-kalman(para=para,Y=data,lik=lik,prev=prev,ahead=ahead) #**** 
results2

# -906.7386 full sample loglik

# Numerical Optimization  

otim1<-optim(para,kalman,control = list(maxit=1000000),Y=data,lik=lik,prev=prev,ahead=ahead)


lik<-FALSE
prev<-FALSE
results<-kalman(para=para,Y=data,lik=lik,prev=prev,ahead=ahead)
results
# residuals v2 summary
#mean
for(i in 1:7)
{
mean_i<-mean(results$v2[,i])
print(mean_i)
}
#RMSE
install.packages("Metrics")
library(Metrics)
for(i in 1:7){
  print(rmse(as.numeric(data[,i]),results$v1[,i]))
}
#forecast rmse
for(i in 1:7){
  print(rmse(as.numeric(data[,i]),results$Yf[,i]))
}

#factors
#results$a.tt
Level_correlated=ts(results$a.tt[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
Slope_correlated=ts(results$a.tt[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
Curvature_correlated=ts(results$a.tt[,3],frequency = 12,start = c(1996,1),end = c(2011,12))