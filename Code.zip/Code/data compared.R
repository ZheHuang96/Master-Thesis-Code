K<-diag(3)
K[1,1]<-0.1236103 
K[1,2]<--0.3346683
K[1,3]<-0.3225620
K[2,1]<--0.2236299
K[2,2]<-0.4007232
K[2,3]<--0.6014589
K[3,1]<-0.7017006
K[3,2]<-0.03921358
K[3,3]<-0.5886448
M<--K*(1/12)
exp(M)
m<-eigen(K,only.values=TRUE)
eigenvalues<-m$values
test<-max(Re(eigenvalues[1]),Re(eigenvalues[2]),Re(eigenvalues[3]))


K<-diag(3)
K[1,1]<-0.6298 
K[1,2]<--0.0095
K[1,3]<-0.0097
K[2,1]<--0.0148
K[2,2]<-0.7854
K[2,3]<--0.0106
K[3,1]<-0.0104
K[3,2]<-0.0115
K[3,3]<-0.7047
M<--K*(1/12)
exp(M)










#











library(readr)
Final_thesis_data <- read_csv("C:/Users/Huang Zhe/Desktop/thesis/code/Final thesis data.csv")
#data format English
Sys.setlocale("LC_TIME", "English")
#2D ts plot
x_1=ts(Final_thesis_data$`1M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_2=ts(Final_thesis_data$`3M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_3=ts(Final_thesis_data$`6M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_4=ts(Final_thesis_data$`24M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_5=ts(Final_thesis_data$`60M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_6=ts(Final_thesis_data$`84M`,frequency = 12,start = c(1996,1),end = c(2011,12))
x_7=ts(Final_thesis_data$`120M`,frequency = 12,start = c(1996,1),end = c(2011,12))
Slope=(as.numeric(x_7)-as.numeric(x_2))/-1
S_empirical=ts(Slope,frequency = 12,start = c(1996,1),end = c(2011,12))
Curvature=(2*as.numeric(x_4)-as.numeric(x_2)-as.numeric(x_7)) #/0.37
C_empirical=ts(Curvature,frequency = 12,start = c(1996,1),end = c(2011,12))





#data for each maturity
Y_1=ts(data[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_3=ts(data[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_6=ts(data[,3],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_24=ts(data[,4],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_60=ts(data[,5],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_84=ts(data[,6],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_120=ts(data[,7],frequency = 12,start = c(1996,1),end = c(2011,12))
Level_empirical<-Y_120

#indep DNS model estimation
Y_indep_1=ts(results$v1[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_3=ts(results$v1[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_6=ts(results$v1[,3],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_24=ts(results$v1[,4],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_60=ts(results$v1[,5],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_84=ts(results$v1[,6],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_120=ts(results$v1[,7],frequency = 12,start = c(1996,1),end = c(2011,12))
L_indep_DNS=ts(results$a.tt[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
S_indep_DNS=ts(results$a.tt[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
C_indep_DNS=ts(results$a.tt[,3],frequency = 12,start = c(1996,1),end = c(2011,12))
#correlated DNS model estimation
Y_correlated_1=ts(results$v1[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_3=ts(results$v1[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_6=ts(results$v1[,3],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_24=ts(results$v1[,4],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_60=ts(results$v1[,5],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_84=ts(results$v1[,6],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_120=ts(results$v1[,7],frequency = 12,start = c(1996,1),end = c(2011,12))
L_correlated_DNS=ts(results$a.tt[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
S_correlated_DNS=ts(results$a.tt[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
C_correlated_DNS=ts(results$a.tt[,3],frequency = 12,start = c(1996,1),end = c(2011,12))

par(mfrow=c(2,1))
ts.plot(Y_1,Y_indep_1,Y_correlated_1,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",cex=0.5,legend=c("1-month data","indep_DNS","correlated_DNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_3,Y_indep_3,Y_correlated_3,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",cex=0.5,legend=c("3-month data","indep_DNS","correlated_DNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_6,Y_indep_6,Y_correlated_6,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",cex=0.5,legend=c("6-month data","indep_DNS","correlated_DNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_24,Y_indep_24,Y_correlated_24,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",cex=0.5,legend=c("24-month data","indep_DNS","correlated_DNS"),col=c("black","blue","red"),bty="n",lty =1)
par(mfrow=c(3,1))
ts.plot(Y_60,Y_indep_60,Y_correlated_60,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",cex=0.5,legend=c("60-month data","indep_DNS","correlated_DNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_84,Y_indep_84,Y_correlated_84,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",cex=0.5,legend=c("84-month data","indep_DNS","correlated_DNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_120,Y_indep_120,Y_correlated_120,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",cex=0.5,legend=c("120-month data","indep_DNS","correlated_DNS"),col=c("black","blue","red"),bty="n",lty =1)





















#indepent AFNS model estimation
Y_indep_1=ts(results$v1[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_3=ts(results$v1[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_6=ts(results$v1[,3],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_24=ts(results$v1[,4],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_60=ts(results$v1[,5],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_84=ts(results$v1[,6],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_indep_120=ts(results$v1[,7],frequency = 12,start = c(1996,1),end = c(2011,12))
L_indep_AFNS=ts(results$a.tt[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
S_indep_AFNS=ts(results$a.tt[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
C_indep_AFNS=ts(results$a.tt[,3],frequency = 12,start = c(1996,1),end = c(2011,12))
#correlated model estimation
Y_correlated_1=ts(results1$v1[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_3=ts(results1$v1[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_6=ts(results1$v1[,3],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_24=ts(results1$v1[,4],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_60=ts(results1$v1[,5],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_84=ts(results1$v1[,6],frequency = 12,start = c(1996,1),end = c(2011,12))
Y_correlated_120=ts(results1$v1[,7],frequency = 12,start = c(1996,1),end = c(2011,12))
L_correlated_AFNS=ts(results1$a.tt[,1],frequency = 12,start = c(1996,1),end = c(2011,12))
S_correlated_AFNS=ts(results1$a.tt[,2],frequency = 12,start = c(1996,1),end = c(2011,12))
C_correlated_AFNS=ts(results1$a.tt[,3],frequency = 12,start = c(1996,1),end = c(2011,12))

#AFNS three factor plot
par(mfrow=c(2,2))
#level
par(mar = c(4,4,4,4))
ts.plot(Level_empirical,L_indep_AFNS,L_correlated_AFNS, gpars = list(col=c("black","blue","red"), xlab="Date", ylab="Yields(%)"))
title(main="The Empirical and Estimated AFNS level")
legend("topright",legend=c("Empirical","AFNS_indep","AFNS_corr"),col=c("black","blue","red"),bty="n",lty =1)
#Slope
par(mar = c(4,4,4,4))
ts.plot(Slope_empirical,S_indep_AFNS,S_correlated_AFNS, gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
title(main="The Empirical and Estimated AFNS Slope")
legend("bottomleft", legend=c("Empirical","AFNS_indep","AFNS_corr"),col=c("black","blue","red"),bty="n",lty =1,xpd = TRUE)
#curvature
par(mar = c(4,4,4,4))
ts.plot(Curvature_empirical,C_indep_AFNS,C_correlated_AFNS, gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
title(main="The Empirical and Estimated AFNS curvature")
legend("bottomleft",legend=c("Empirical","AFNS_indep","AFNS_corr"),col=c("black","blue","red"),bty="n",lty =1)
#
par(mfrow=c(2,2))
ts.plot(Y_1,Y_indep_1,Y_correlated_1,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",legend=c("1-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_3,Y_indep_3,Y_correlated_3,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",legend=c("3-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_6,Y_indep_6,Y_correlated_6,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",legend=c("6-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_24,Y_indep_24,Y_correlated_24,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",legend=c("24-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
par(mfrow=c(3,1))
ts.plot(Y_60,Y_indep_60,Y_correlated_60,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",cex=0.5,legend=c("60-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_84,Y_indep_84,Y_correlated_84,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",cex=0.5,legend=c("84-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_120,Y_indep_120,Y_correlated_120,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="Yields(%)"))
legend("topright",cex=0.5,legend=c("120-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)

par(mfrow=c(3,3))
ts.plot(Y_1,Y_indep_1,Y_correlated_1,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="1M Yields(%)"))
#legend("topright",legend=c("1-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_3,Y_indep_3,Y_correlated_3,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="3M Yields(%)"))
#legend("topright",legend=c("3-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_6,Y_indep_6,Y_correlated_6,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="6M Yields(%)"))
#legend("topright",legend=c("6-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_24,Y_indep_24,Y_correlated_24,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="24M Yields(%)"))
#legend("topright",legend=c("24-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
#par(mfrow=c(3,1))
ts.plot(Y_60,Y_indep_60,Y_correlated_60,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="60M Yields(%)"))
#legend("topright",cex=0.5,legend=c("60-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_84,Y_indep_84,Y_correlated_84,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="84M Yields(%)"))
#legend("topright",cex=0.5,legend=c("84-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)
ts.plot(Y_120,Y_indep_120,Y_correlated_120,gpars = list(col=c("black","blue","red"),xlab="Date", ylab="120M Yields(%)"))
#legend("topright",cex=0.5,legend=c("120-month data","indep_AFNS","correlated_AFNS"),col=c("black","blue","red"),bty="n",lty =1)




#residual QQ plot

par(mfrow=c(3,3))
qqnorm(results$v2[,1])
qqline(results$v2[,1]) 
qqnorm(results$v2[,2])
qqline(results$v2[,2])
qqnorm(results$v2[,3])
qqline(results$v2[,3]) 
qqnorm(results$v2[,4])
qqline(results$v2[,4]) 
qqnorm(results$v2[,5])
qqline(results$v2[,5])
qqnorm(results$v2[,6])
qqline(results$v2[,6]) 
qqnorm(results$v2[,7])
qqline(results$v2[,7]) 


